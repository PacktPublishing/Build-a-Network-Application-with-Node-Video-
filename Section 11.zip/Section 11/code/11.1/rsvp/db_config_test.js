module.exports = {
  "host":   "localhost",
  "db":     "rsvp_test",
  "port":   27017,
  "user":   "test",
  "pass":   "123"
};