module.exports = {
  "host":   "localhost",
  "db":     "rsvp",
  "port":   27017,
  "user":   "rsvp",
  "pass":   "awesomesauce"
};