A gravatar-based event RSVP app
